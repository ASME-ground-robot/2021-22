// Auto-generated. Do not edit!

// (in-package rover_control.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ControlCommands {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.StartupCmd = null;
      this.IdleCmd = null;
      this.DiagnosticCmd = null;
    }
    else {
      if (initObj.hasOwnProperty('StartupCmd')) {
        this.StartupCmd = initObj.StartupCmd
      }
      else {
        this.StartupCmd = false;
      }
      if (initObj.hasOwnProperty('IdleCmd')) {
        this.IdleCmd = initObj.IdleCmd
      }
      else {
        this.IdleCmd = false;
      }
      if (initObj.hasOwnProperty('DiagnosticCmd')) {
        this.DiagnosticCmd = initObj.DiagnosticCmd
      }
      else {
        this.DiagnosticCmd = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ControlCommands
    // Serialize message field [StartupCmd]
    bufferOffset = _serializer.bool(obj.StartupCmd, buffer, bufferOffset);
    // Serialize message field [IdleCmd]
    bufferOffset = _serializer.bool(obj.IdleCmd, buffer, bufferOffset);
    // Serialize message field [DiagnosticCmd]
    bufferOffset = _serializer.bool(obj.DiagnosticCmd, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ControlCommands
    let len;
    let data = new ControlCommands(null);
    // Deserialize message field [StartupCmd]
    data.StartupCmd = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [IdleCmd]
    data.IdleCmd = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [DiagnosticCmd]
    data.DiagnosticCmd = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 3;
  }

  static datatype() {
    // Returns string type for a message object
    return 'rover_control/ControlCommands';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '94d686c1501c58970b95b53d2dba06f1';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool StartupCmd
    bool IdleCmd
    bool DiagnosticCmd
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ControlCommands(null);
    if (msg.StartupCmd !== undefined) {
      resolved.StartupCmd = msg.StartupCmd;
    }
    else {
      resolved.StartupCmd = false
    }

    if (msg.IdleCmd !== undefined) {
      resolved.IdleCmd = msg.IdleCmd;
    }
    else {
      resolved.IdleCmd = false
    }

    if (msg.DiagnosticCmd !== undefined) {
      resolved.DiagnosticCmd = msg.DiagnosticCmd;
    }
    else {
      resolved.DiagnosticCmd = false
    }

    return resolved;
    }
};

module.exports = ControlCommands;
